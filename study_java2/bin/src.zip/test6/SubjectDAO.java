package test6;

import java.util.ArrayList;
import java.util.Scanner;

public class SubjectDAO {

	private Scanner scan = new Scanner(System.in);
	private ArrayList<Subject> subjectList = new ArrayList<Subject>();
	
	public void insertSubject(StudentDAO studentDAO) {
		// TODO Auto-generated method stub
		
	}
	public void deleteSubject(StudentDAO studentDAO) {
		// TODO Auto-generated method stub
		
	}
}