package test6;

public class main {

	public static void main(String[] args) {
		
		Controller con = new Controller();
		con.run();
		
	}

}
