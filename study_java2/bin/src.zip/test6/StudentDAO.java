package test6;

import java.util.ArrayList;
import java.util.Scanner;

public class StudentDAO {
	
	private Student s = null;
	private Scanner scan = new Scanner(System.in);
	private ArrayList<Student> studentList = new ArrayList<Student>();
	private int num = 1000;

	private int addnum() {
		num++;
		return num;
	}
	
	private boolean isStudentList() {
		if(studentList.size() == 0) { System.out.println("[학생목록이 없습니다.]");return true;}
		return false;
	}
	
	private boolean isDuplicationId(String id) {
//		if (!isStudentList()) {
			for (Student s : studentList) {
				if (s.getStudentId().equals(id))
					return true;
			}
//		}
		return false;
	}
	
	private String getvalue(String msg) {
		System.out.print(msg);
		String id = null;
		try {
			id = scan.next();
			int cnt = 0;
			if (isDuplicationId(id)) {
				throw new Exception("[중복 아이디 있음]");
			}
			for (int i = 0; i < id.length(); i++) {
				if (id.charAt(i) >= '0' && id.charAt(i) <= '9') { // 48 57
					cnt++;
				}
			}
			if (cnt == id.length()) {
				throw new Exception("[숫자만으로 아이디생성 불가]");
			}

		} catch (Exception e) {
			id = null;
			System.out.println(e.getMessage());
		}
		return id;
	}
	
	public void join() {
		String id = null;
		while(id == null) {
			id = getvalue("아이디 입력 >>");
		}
		studentList.add(s = new Student(addnum(), id));
	}

	public void deleteStudent(SubjectDAO subjectDAO) {
		if(isStudentList()) {return;}
		
	}

	public void printStudentList(SubjectDAO subjectDAO) {
		if(isStudentList()) {return;}
		
		for(Student s : studentList) {
			System.out.println(s);
		}
		
	}

	public void saveStudentList(SubjectDAO subjectDAO) {
		if(isStudentList()) {return;}
		
	}

	public void loadStudentList(SubjectDAO subjectDAO) {
	
		
	}






	
}