package test6;

public class Student {
	private int studentNum; // 1씩 자동증가 1001~  
	private String studentId; // 중복금지
	
	public Student(int studentNum, String studentId) {
		super();
//		this.studentNum = studentNum;
//		this.studentId = studentId;
		setStudentNum(studentNum);
		setStudentId(studentId);
	}
	
	

	public int getStudentNum() {
		return studentNum;
	}

	private void setStudentNum(int studentNum) {
		this.studentNum = studentNum;
	}

	public String getStudentId() {
		return studentId;
	}

	private void setStudentId(String studentId) {
		this.studentId = studentId;
	}



	@Override
	public String toString() {
		return "Student [studentNum=" + studentNum + ", studentId=" + studentId + "]";
	}
	
	
	
}