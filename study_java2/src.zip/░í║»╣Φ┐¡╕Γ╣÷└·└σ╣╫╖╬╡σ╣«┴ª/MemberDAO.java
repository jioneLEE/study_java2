package 가변배열멤버저장및로드문제;

import java.util.Scanner;

public class MemberDAO {
	int num; // 학번 1001 시작 
	Member[] memberList;
	
	MemberDAO(){
//		int cnt =1;
//		memberList = new Member[cnt];
		num = 1001;
	}

	String getValue(String msg) {
		// id 입력 받을 때 숫자값만 입력받으면 id 는 적어도 한개 문자값 포함이라는
		// 예외처리 적용해보세요
		Scanner sc = new Scanner(System.in);
		System.out.println(msg + " > ");
		String val = "";
		try {
			val = sc.next();
			boolean check = false;
			for (int i = 0; i < val.length(); i++) {
				if (val.charAt(i) < '0' || val.charAt(i) > '9') {
					check = true;
				}
			}
			if (!check) {
				throw new Exception("[err 아이디에 문자가 1개이상 포함되어있어야됨]");
			}

		} catch (Exception e) {
//				e.printStackTrace();
			System.out.println(e.getMessage());
			return "";
		}

		return val;
	}
	
   void join() {
		while (true) {
			String id = getValue("아이디 입력");
			if (id == "") {
				continue;
			}
			
			
			break;
		}
	  
   }
	void remove() {} // 삭제하고자 하는 학번 입력 
	void update() {} //수정 하고자 하는 학번입력하면 아이디 수정 
	void printMember(){}
	void saveData() {
		// 저장패턴 memberList.text
		// 아이디,학번\n 이렇게 한줄로 저장 
		
		// 저장예시
		// 1001,test1\nl002,test2  
		
	}
	void loadData() {}
}