package 가변배열멤버저장및로드문제;

public class MemberMain {
	public static void main(String[] args) {
		
		MemberController mc = new MemberController();
		mc.mainMenu();
		
	}
}