package 메서드2_문제;

public class 클배문제10_회원관리 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
