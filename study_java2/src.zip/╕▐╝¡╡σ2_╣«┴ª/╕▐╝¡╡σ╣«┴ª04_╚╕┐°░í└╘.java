package 메서드2_문제;

public class 메서드문제04_회원가입 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
