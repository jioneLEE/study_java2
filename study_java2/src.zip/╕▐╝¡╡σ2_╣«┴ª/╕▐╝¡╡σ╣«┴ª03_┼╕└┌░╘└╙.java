package 메서드2_문제;

public class 메서드문제03_타자게임 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
