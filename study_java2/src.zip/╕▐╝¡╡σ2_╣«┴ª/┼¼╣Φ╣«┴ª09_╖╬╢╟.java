package 메서드2_문제;

public class 클배문제09_로또 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
