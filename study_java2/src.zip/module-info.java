module study_java2 {
}