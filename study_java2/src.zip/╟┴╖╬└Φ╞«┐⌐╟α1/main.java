package 프로잭트여행1;

public class main {

	public static void main(String[] args) {
		
		controller g = new controller();
		g.run();
		

	}

}