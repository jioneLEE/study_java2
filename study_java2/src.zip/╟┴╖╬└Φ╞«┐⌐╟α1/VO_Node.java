package 프로잭트여행1;

class VO_Node{
	int y;
	int x;
}
