package 클래스배열;

public class 클배문제05_테스트1 {
	
	public static void main(String[] args) {
		
		
	}

}
