package 클래스배열;

public class 클배문제04_학생컨트롤러2단계 {
	
	public static void main(String[] args) {
		
		
	}

}
